var menu = document.getElementById("menu");
var buttonmain = document.getElementById("buttonmain");
var buttonhome = document.getElementById("buttonhome");
var buttonbelajar = document.getElementById("buttonbelajar");
var buttoncara = document.getElementById("buttoncara");
var belajar = document.getElementById("belajar"); 
var belajarJatim = document.getElementById("belajarJatim");
var belajarMaluku = document.getElementById("belajarMaluku");
var btnmute = document.getElementById("mute")
var main = document.getElementById("main");
var buttonkembalihome = document.getElementById("buttonkembalihome");
var buttonmaluku = document.getElementById("buttonmaluku");
var buttonjawatimur = document.getElementById("buttonjawatimur");
var provinsi = document.getElementById("provinsi");
var Jawatimur = false;
var Maluku = false;
var buttonmulai = document.getElementById("buttonmulai");
var jatimkartun = document.getElementById("jatimkartun");
var soal = document.getElementById("soal");


var musik = new Audio();
musik.src = "audio/SATU NUSA SATU BANGSA - INSTRUMENTAL ANAK.mp3";
musik.loop = true;
musik.play();

function mulaiAudio() {

    var mute = document.getElementById("mute");


    mute.addEventListener('click', fmute);



    function fmute() {
        if (musik.muted) {
            musik.muted = false;
            mute.style.background = "url(images/unmute.png)";
        } else {
            musik.muted = true;
            mute.style.background = "url(images/mute.png)";
        }


    }
}
window.addEventListener('load', mulaiAudio);

function play() {
    main.style.display = "block";
    menu.style.display = "none";
    buttonkembalihome.style.display = "block";
    buttonmaluku.style.display = "block";
    buttonjawatimur.style.display = "block";


}

function rumah() {
    belajar.style.display = "none";
    belajarJatim.style.display = "none"; 
    belajarMaluku.style.display = "none";
    caraBermain.style.display = "none";
    main.style.display = "none";
    buttonkembalihome.style.display = "none";
    buttonmaluku.style.display = "none";
    buttonjawatimur.style.display = "none";
    menu.style.display = "block";
    mute.style.display = "block";


}

function study() {
    belajar.style.display = "block";
    menu.style.display = "none";
    buttonkembalihome.style.display = "block";
    buttonmaluku.style.display = "block";
    buttonjawatimur.style.display = "block";
    belajarJatim.style.display = "none";
    belajarMaluku.style.display = "none";
}

function sinauJatim(){
    belajar.style.display = "none";
    belajarJatim.style.display = "block";
    belajarMaluku.style.display = "none";
    buttonkembalihome.style.display = "none";
    buttonmaluku.style.display = "none";
    buttonjawatimur.style.display = "none";
    main.style.display = "none";
    mute.style.display = "none";
    
}

function sinauMaluku(){
    belajar.style.display = "none";
    belajarMaluku.style.display = "block";
    belajarJatim.style.display = "none";
    buttonkembalihome.style.display = "block";
    buttonmaluku.style.display = "none";
    buttonjawatimur.style.display = "none";
    main.style.display = "none";
    mute.style.display = "none";
}

function caraMain() {
    menu.style.display = "none";
    caraBermain.style.display = "block";
    buttonkembalihome.style.display = "block";
}

function jatim() {
    Jawatimur = true;
    kuismulai.style.display = "block";
    provinsi.innerHTML = "<h3>Provinsi: Jawa Timur</h3>";
    provinsi.style.display = "block";
    buttonkembalihome.style.display = "none";
    buttonmaluku.style.display = "none";
    buttonjawatimur.style.display = "none";
    main.style.display = "none"
    jatimkartun.style.display = "block"
}

function maluku() {
    Maluku = true;
    kuismulai.style.display = "block";
    provinsi.innerHTML = "<h3>Provinsi: Maluku</h3>";
    provinsi.style.display = "block";
    buttonkembalihome.style.display = "none";
    buttonmaluku.style.display = "none";
    buttonjawatimur.style.display = "none";
    main.style.display = "none"
    malukukartun.style.display = "block"
}

function start() {
    if (Maluku == true) {
        NextQuestionMaluku(0);
        soal.style.display = "block";
        buttonmulai.style.display = "none";
        kuismulai.style.display = "none"
        malukukartun.style.display = "none"

    } else {
        NextQuestionJatim(0);
        soal.style.display = "block";
        buttonmulai.style.display = "none";
        kuismulai.style.display = "none"
        jatimkartun.style.display = "none";
    }
}


const questionsMaluku = [{
        question: "Berikut ini yang merupakan rumah adat Maluku",
        optionA: "Kesepuhan",
        optionB: "Bangsal Kencono",
        optionC: "Joglo",
        optionD: "Baileo",
        correctOption: "optionD"
    },

    {
        question: "Senjata tradisional khas Maluku adalah",
        optionA: "Kujang",
        optionB: "Golok",
        optionC: "Salawaku",
        optionD: "Keris",
        correctOption: "optionC"
    },

    {
        question: "Berikut merupakan lagu daerah yang berasal dari Maluku, kecuali? ",
        optionA: "Jali-jali",
        optionB: "Ambon Manise",
        optionC: "Goro-goro",
        optionD: "Sarinande",
        correctOption: "optionA"
    },

    {
        question: "Tarian tradisional Provinsi Maluku yaitu",
        optionA: "Serimpi",
        optionB: "Topeng",
        optionC: "Yapong",
        optionD: "Lenso",
        correctOption: "optionD"
    },

    {
        question: "Pakaian adat tradisional Maluku dikenal dengan?",
        optionA: "Baju Kebaya",
        optionB: "Baju Kesatrian",
        optionC: "Baju Cele",
        optionD: "Baju Pesa'an",
        correctOption: "optionC"
    }

]

const questionsJatim = [{
        question: "Pakaian adat Provinsi Jawa timur yaitu ?",
        optionA: "Pesa'an",
        optionB: "Teluk Belanga",
        optionC: "Kebaya",
        optionD: "Ulos",
        correctOption: "optionA"
    },

    {
        question: "Berikut ini yang merupakan lagu daerah provinsi Jawa Timur, kecuali?",
        optionA: "Rek ayo Rek",
        optionB: "Keraban Sape",
        optionC: "Es Lilin",
        optionD: "Gai Bintang",
        correctOption: "optionC"
    },
    {
        question: "Tarian daerah provinsi Jawa Timur adalah",
        optionA: "Serimpi",
        optionB: "Kecak",
        optionC: "Remong",
        optionD: "Merak",
        correctOption: "optionC"
    },

    {
        question: "Bahasa daerah yang digunakan di provinsi Jawa Timur, diantaranya?",
        optionA: "Bahasa Jawa dan Madura",
        optionB: "Melayu",
        optionC: "Banda",
        optionD: "Tanimbar",
        correctOption: "optionA"
    },



    {
        question: "Rumah ada provinsi Jawa Timur yaitu",
        optionA: "Bangsal Kencono",
        optionB: "Lamin",
        optionC: "Joglo",
        optionD: "Kesepuhan",
        correctOption: "optionC"
    }

]
let shuffledQuestions = [] //empty array to hold shuffled selected questions

function handleQuestions() {
    if (Maluku == true) {
        //function to shuffle and push 10 questions to shuffledQuestions array
        while (shuffledQuestions.length <= 4) {
            const random = questionsMaluku[Math.floor(Math.random() * questionsMaluku.length)]
            if (!shuffledQuestions.includes(random)) {
                shuffledQuestions.push(random)
            }
        }
    } else {
        while (shuffledQuestions.length <= 4) {
            const random = questionsJatim[Math.floor(Math.random() * questionsJatim.length)]
            if (!shuffledQuestions.includes(random)) {
                shuffledQuestions.push(random)
            }
        }
    }
}


let questionNumber = 1
let playerScore = 0
let wrongAttempt = 0
let indexNumber = 0

// function for displaying next question in the array to dom
function NextQuestionJatim(index) {
    handleQuestions()
    const currentQuestion = shuffledQuestions[index]
    document.getElementById("question-number").innerHTML = questionNumber
    document.getElementById("player-score").innerHTML = playerScore
    document.getElementById("display-question").innerHTML = currentQuestion.question;
    document.getElementById("option-one-label").innerHTML = currentQuestion.optionA;
    document.getElementById("option-two-label").innerHTML = currentQuestion.optionB;
    document.getElementById("option-three-label").innerHTML = currentQuestion.optionC;
    document.getElementById("option-four-label").innerHTML = currentQuestion.optionD;

}

function NextQuestionMaluku(index) {
    handleQuestions()
    const currentQuestion = shuffledQuestions[index]
    document.getElementById("question-number").innerHTML = questionNumber
    document.getElementById("player-score").innerHTML = playerScore
    document.getElementById("display-question").innerHTML = currentQuestion.question;
    document.getElementById("option-one-label").innerHTML = currentQuestion.optionA;
    document.getElementById("option-two-label").innerHTML = currentQuestion.optionB;
    document.getElementById("option-three-label").innerHTML = currentQuestion.optionC;
    document.getElementById("option-four-label").innerHTML = currentQuestion.optionD;

}

function checkForAnswer() {
    const currentQuestion = shuffledQuestions[indexNumber] //gets current Question 
    const currentQuestionAnswer = currentQuestion.correctOption //gets current Question's answer
    const options = document.getElementsByName("option"); //gets all elements in dom with name of 'option' (in this the radio inputs)
    let correctOption = null

    options.forEach((option) => {
        if (option.value === currentQuestionAnswer) {
            //get's correct's radio input with correct answer
            correctOption = option.labels[0].id
        }
    })

    //checking to make sure a radio input has been checked or an option being chosen
    if (options[0].checked === false && options[1].checked === false && options[2].checked === false && options[3].checked == false) {
        document.getElementById('option-modal').style.display = "flex"
    }

    //checking if checked radio button is same as answer
    options.forEach((option) => {
        if (option.checked === true && option.value === currentQuestionAnswer) {
            document.getElementById(correctOption).style.backgroundColor = "green"
            playerScore++
            indexNumber++
            //set to delay question number till when next question loads
            setTimeout(() => {
                questionNumber++
            }, 1000)
        } else if (option.checked && option.value !== currentQuestionAnswer) {
            const wrongLabelId = option.labels[0].id
            document.getElementById(wrongLabelId).style.backgroundColor = "red"
            document.getElementById(correctOption).style.backgroundColor = "green"
            wrongAttempt++
            indexNumber++
            //set to delay question number till when next question loads
            setTimeout(() => {
                questionNumber++
            }, 1000)
        }
    })
}



//called when the next button is called
function handleNextQuestion() {
    checkForAnswer()
    unCheckRadioButtons()
        //delays next question displaying for a second
    setTimeout(() => {
        if (indexNumber <= 4) {
            NextQuestionJatim(indexNumber)
        } else {
            handleEndGame()
        }
        resetOptionBackground()
    }, 1000);
}

//sets options background back to null after display the right/wrong colors
function resetOptionBackground() {
    const options = document.getElementsByName("option");
    options.forEach((option) => {
        document.getElementById(option.labels[0].id).style.backgroundColor = ""
    })
}

// unchecking all radio buttons for next question(can be done with map or foreach loop also)
function unCheckRadioButtons() {
    const options = document.getElementsByName("option");
    for (let i = 0; i < options.length; i++) {
        options[i].checked = false;
    }
}

// function for when all questions being answered
function handleEndGame() {
    let remark = null
    let remarkColor = null

    // condition check for player remark and remark color
    if (playerScore <= 2) {
        remark = "Nilai kurang memuaskan, terluslah berlatih!"
        remarkColor = "red"
    } else if (playerScore <= 3) {
        remark = "Kerja bagus, tetap semangat untuk belajar!"
        remarkColor = "orange"
    } else if (playerScore >= 4) {
        remark = "Sangat bagus!, pertahankan nilai kamu."
        remarkColor = "green"
    }
    const playerGrade = (playerScore / 5) * 100

    //data to display to score board
    document.getElementById('remarks').innerHTML = remark
    document.getElementById('remarks').style.color = remarkColor
    document.getElementById('grade-percentage').innerHTML = playerGrade
    document.getElementById('wrong-answers').innerHTML = wrongAttempt
    document.getElementById('right-answers').innerHTML = playerScore
    document.getElementById('score-modal').style.display = "flex"

}

//closes score modal and resets game
function closeScoreModal() {
    if (Jawatimur == true) {
        questionNumber = 1
        playerScore = 0
        wrongAttempt = 0
        indexNumber = 0
        shuffledQuestions = []
        NextQuestionJatim(indexNumber)
        document.getElementById('score-modal').style.display = "none"
    } else {
        questionNumber = 1
        playerScore = 0
        wrongAttempt = 0
        indexNumber = 0
        shuffledQuestions = []
        NextQuestionMaluku(indexNumber)
        document.getElementById('score-modal').style.display = "none"
    }

}

//function to close warning modal
function closeOptionModal() {
    document.getElementById('option-modal').style.display = "none"
}